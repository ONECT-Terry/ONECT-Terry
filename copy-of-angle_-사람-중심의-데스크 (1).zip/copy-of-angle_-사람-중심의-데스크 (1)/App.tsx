
import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Philosophy from './components/Philosophy';
import CoreFeatures from './components/CoreFeatures';
import UseCases from './components/UseCases';
import IntuitiveFunctions from './components/IntuitiveFunctions';
import ProductGallery from './components/ProductGallery';
import Faq from './components/Faq';
import Footer from './components/Footer';

function App() {
  return (
    <div className="bg-white">
      <Header />
      <main>
        <Hero />
        <Philosophy />
        <CoreFeatures />
        <UseCases />
        <IntuitiveFunctions />
        <ProductGallery />
        <Faq />
      </main>
      <Footer />
    </div>
  );
}

export default App;