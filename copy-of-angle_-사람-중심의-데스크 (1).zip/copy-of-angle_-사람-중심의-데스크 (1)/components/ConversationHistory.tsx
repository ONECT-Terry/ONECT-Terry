
import React from 'react';

interface Message {
  type: 'user' | 'model';
  text: string;
}

// Placeholder conversation data based on user interactions
const conversationHistory: Message[] = [
    {
        type: 'user',
        text: '이 웹사이트를 실제 웹사이트로 게시(배포)하는 방법을 알려줘.'
    },
    {
        type: 'model',
        text: `안녕하세요! 이 프로젝트를 실제 웹사이트로 게시(배포)하는 방법을 안내해 드립니다.

이 웹사이트는 '정적(static) 사이트'로 만들어져 있어 배포가 매우 간단합니다. 복잡한 서버 설정 없이 파일을 웹 호스팅 공간에 올리기만 하면 됩니다.

## 배포 방법 (가장 간단한 방법)

프로젝트에 포함된 모든 파일과 폴더를 그대로 웹 호스팅 서버에 업로드하면 됩니다.

**업로드 대상 파일 및 폴더 목록:**

*   \`index.html\`
*   \`index.tsx\`
*   \`App.tsx\`
*   \`types.ts\`
*   \`metadata.json\`
*   \`README.md\` (이 파일)
*   \`components/\` (폴더 안의 모든 파일 포함)
*   모든 이미지 파일들 (예: \`user_image_1.jpg\`)

**배포 절차:**

1.  웹 호스팅 서비스를 준비합니다. (Netlify, Vercel, GitHub Pages와 같은 무료 서비스나, 카페24, 가비아 같은 유료 호스팅을 사용할 수 있습니다.)
2.  호스팅 서비스에서 제공하는 파일 관리자나 FTP 프로그램을 사용하여 위 목록의 모든 파일과 폴더를 서버의 최상위 디렉토리(예: \`public_html\`, \`www\`)에 업로드합니다.
3.  업로드가 완료되면 부여받은 도메인 주소(예: \`https://my-angle-desk.netlify.app\`)로 접속하여 웹사이트가 잘 보이는지 확인합니다.

이것으로 배포가 완료됩니다! 이 방식은 별도의 '빌드' 과정 없이 소스 코드를 그대로 사용하는 현대적인 방식입니다.

---

**참고:** 코드에 사용된 이미지 파일 (\`/user_image_1.jpg\` 등)들은 서버의 가장 최상위 위치에 있어야 합니다. 만약 이미지들을 별도의 폴더(예: \`/images/\`)에 넣어 업로드했다면, 코드의 이미지 경로(\`<img src="/images/user_image_1.jpg" ... />\`)도 모두 수정해주셔야 합니다.`
    },
    {
        type: 'user',
        text: '우리가 나눴던 대화 기록들을 볼 수 있나?'
    }
];


interface ConversationHistoryProps {
  isVisible: boolean;
  onClose: () => void;
}

const ConversationHistory: React.FC<ConversationHistoryProps> = ({ isVisible, onClose }) => {
  if (!isVisible) {
    return null;
  }

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-60 z-50 transition-opacity duration-300 ease-in-out"
      onClick={onClose}
      aria-modal="true"
      role="dialog"
    >
      <div
        className="fixed top-0 right-0 h-full w-full max-w-md bg-white shadow-2xl flex flex-col animate-slide-in"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center p-4 border-b border-gray-200 flex-shrink-0">
          <h2 className="text-xl font-bold text-gray-800">대화 기록</h2>
          <button
            onClick={onClose}
            aria-label="닫기"
            className="p-2 text-gray-500 hover:text-gray-800 hover:bg-gray-100 rounded-full"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <div className="flex-grow overflow-y-auto p-4 space-y-4">
          {conversationHistory.map((message, index) => (
            <div key={index} className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div
                className={`max-w-xs md:max-w-sm rounded-xl px-4 py-3 ${
                  message.type === 'user'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-100 text-gray-800'
                }`}
              >
                <p className="whitespace-pre-wrap text-sm">{message.text}</p>
              </div>
            </div>
          ))}
           <div className="flex justify-start">
              <div className="max-w-xs md:max-w-sm rounded-xl px-4 py-3 bg-gray-100 text-gray-800">
                <p className="whitespace-pre-wrap text-sm">네, 가능합니다. 방금 추가된 '대화 기록' 버튼을 통해 이전 대화 내용을 확인하실 수 있습니다.</p>
              </div>
            </div>
        </div>
      </div>
       <style>{`
          @keyframes slide-in {
            from { transform: translateX(100%); }
            to { transform: translateX(0); }
          }
          .animate-slide-in {
            animation: slide-in 0.3s ease-out forwards;
          }
        `}</style>
    </div>
  );
};

export default ConversationHistory;
