import React from 'react';

const FeatureItem: React.FC<{ title: string, description: string, imageUrl: string }> = ({ title, description, imageUrl }) => (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden transition-transform transform hover:-translate-y-1">
        <img className="h-56 w-full object-cover" src={imageUrl} alt={title} />
        <div className="p-6">
            <h3 className="text-lg leading-6 font-semibold text-gray-900">{title}</h3>
            <p className="mt-3 text-base text-gray-600">{description}</p>
        </div>
    </div>
);

const CoreFeatures: React.FC = () => {
  return (
    <div className="py-16 bg-white sm:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:text-center">
          <h2 className="text-base text-indigo-600 font-semibold tracking-wide uppercase">디자인 요소</h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
            안전과 지속가능성을 담은 설계
          </p>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
            심플한 바디, 교체 가능한 가림판, 그리고 사용자의 안전을 고려한 라운드 마감은 angle 디자인의 핵심 요소입니다. 각진 모서리의 날카로움 대신 부드럽고 따뜻한 느낌을 선사합니다.
          </p>
        </div>

        <div className="mt-12 grid gap-10 md:grid-cols-2 lg:grid-cols-2">
          <FeatureItem
            title="심플하고 견고한 바디"
            description="원형 금속 파이프를 사용하여 심플하고 세련된 느낌을 주며, 동시에 뛰어난 구조적 안정성을 확보했습니다."
            imageUrl="./user_image_4.jpg"
          />
          <FeatureItem
            title="지속가능한 가림판"
            description="다양한 소재와 색상 적용이 가능하며, 파손 시 손쉽게 교체할 수 있어 지속 가능성이 높고 사용자의 취향을 반영하기 좋습니다."
            imageUrl="./user_image_12.jpg"
          />
        </div>
      </div>
    </div>
  );
};

export default CoreFeatures;