import React, { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { ChartData } from '../types';

const data: ChartData[] = [
  { name: '핵심 기능', value: 45 },
  { name: '인체공학', value: 38 },
  { name: '공간 효율', value: 17 },
];

const COLORS = ['#4f46e5', '#7c3aed', '#a78bfa'];

const DataVisualization: React.FC = () => {
  // A simple trick to ensure the chart renders correctly on the client-side
  const [isClient, setIsClient] = useState(false);
  useEffect(() => {
    setIsClient(true);
  }, []);

  return (
    <div className="bg-gray-50 py-16 sm:py-24">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-base font-semibold text-indigo-600 tracking-wider uppercase">데이터 시각화</h2>
          <p className="mt-2 text-3xl font-extrabold text-gray-900 tracking-tight sm:text-4xl">
            주요 기능 구성 비율
          </p>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            'angle' 데스크 시리즈 주요 기능 구성 (가상 데이터).
          </p>
        </div>
        <div className="mt-12" style={{ width: '100%', height: 300 }}>
          {isClient && (
            <ResponsiveContainer>
              <BarChart data={data} layout="vertical" margin={{ top: 20, right: 30, left: 30, bottom: 5 }}>
                <XAxis type="number" hide />
                <YAxis type="category" dataKey="name" stroke="#4b5563" width={120} tickLine={false} axisLine={false} />
                <Tooltip
                    cursor={{fill: 'transparent'}}
                    contentStyle={{ background: '#ffffff', border: '1px solid #e5e7eb', borderRadius: '0.5rem' }}
                    labelStyle={{ fontWeight: 'bold', color: '#111827' }}
                    formatter={(value: number) => [`${value}%`, '비중']}
                />
                <Bar dataKey="value" barSize={35} radius={[0, 10, 10, 0]}>
                   {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>
    </div>
  );
};

export default DataVisualization;