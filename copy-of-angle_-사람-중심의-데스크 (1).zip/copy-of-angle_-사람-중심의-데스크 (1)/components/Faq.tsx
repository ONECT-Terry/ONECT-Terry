import React, { useState } from 'react';
import { AccordionItem } from '../types';

const faqData: AccordionItem[] = [
  {
    title: '효율적인 작동 방식',
    content: '모든 기능은 전력 없이 유압식과 기계식 구조로 작동하여, 안정적이고 유지보수가 용이하며 어떤 환경에서도 사용이 가능합니다.',
  },
  {
    title: '디자인 요약',
    content: 'angle 시리즈는 사용자의 필요에 맞춘 추가 기능과 효율적인 설계를 통해 교육 및 업무 환경의 질을 높입니다. 그 적응형 디자인은 더 나은 자세, 향상된 집중력, 그리고 효율적인 공간 관리를 지원합니다.',
  },
];


const AccordionItemComponent: React.FC<{
  item: AccordionItem;
  isOpen: boolean;
  onClick: () => void;
}> = ({ item, isOpen, onClick }) => {
  return (
    <div className="border-t border-gray-200">
      <dt>
        <button
          onClick={onClick}
          className="flex w-full items-start justify-between py-6 text-left text-gray-400"
          aria-expanded={isOpen}
        >
          <span className="font-medium text-gray-900">{item.title}</span>
          <span className="ml-6 flex h-7 items-center">
            <svg
              className={`h-6 w-6 transform ${isOpen ? '-rotate-180' : 'rotate-0'} transition-transform duration-200`}
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth="2"
              stroke="currentColor"
              aria-hidden="true"
            >
              <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
            </svg>
          </span>
        </button>
      </dt>
      {isOpen && (
        <dd className="pb-6 pr-12">
          <p className="text-base text-gray-500">{item.content}</p>
        </dd>
      )}
    </div>
  );
};

const Faq: React.FC = () => {
    const [openIndex, setOpenIndex] = useState<number | null>(0);

    const handleToggle = (index: number) => {
        setOpenIndex(openIndex === index ? null : index);
    };

  return (
    <div className="bg-white">
      <div className="mx-auto max-w-7xl py-12 px-4 sm:py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-3xl divide-y-2 divide-gray-200">
          <h2 className="text-center text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">요약 정보</h2>
          <dl className="mt-6 space-y-6 divide-y divide-gray-200">
            {faqData.map((item, index) => (
                <AccordionItemComponent
                    key={index}
                    item={item}
                    isOpen={openIndex === index}
                    onClick={() => handleToggle(index)}
                />
            ))}
          </dl>
        </div>
      </div>
    </div>
  );
};

export default Faq;