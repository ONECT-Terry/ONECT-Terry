import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800">
      <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <p className="text-center text-base text-gray-400">
          본 페이지는 제공된 'angle' 제품 발표 자료를 기반으로 제작되었습니다.
        </p>
        <p className="mt-2 text-center text-sm text-gray-500">
          &copy; {new Date().getFullYear()} Angle Desk. 모든 권리 보유.
        </p>
      </div>
    </footer>
  );
};

export default Footer;