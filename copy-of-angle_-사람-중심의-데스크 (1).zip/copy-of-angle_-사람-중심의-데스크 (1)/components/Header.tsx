
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-white/80 backdrop-blur-md sticky top-0 z-40 border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex-shrink-0">
            <h1 className="text-2xl font-bold text-gray-900 tracking-tight">angle:</h1>
          </div>
          <div className="flex items-center space-x-4">
            <span className="hidden md:block text-sm font-medium text-gray-500">사람 중심의 데스크</span>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;