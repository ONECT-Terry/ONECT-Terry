import React from 'react';

const Hero: React.FC = () => {
  return (
    <div className="relative bg-gray-900">
      <div className="absolute inset-0">
        <img
          className="w-full h-full object-cover"
          src="./user_image_1.jpg"
          alt="angle 데스크가 배치된 현대적인 교실 전경"
        />
        <div className="absolute inset-0 bg-gray-700 mix-blend-multiply" aria-hidden="true" />
      </div>
      <div className="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8 text-center">
        <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
          angle: 사람 중심의 데스크
        </h1>
        <p className="mt-6 max-w-3xl mx-auto text-xl text-indigo-100">
          편리성, 기능성, 활용성을 더한 사용자 중심 디자인. 안전성과 인체공학적 설계를 동시에 고려한 angle 데스크 시리즈를 만나보세요.
        </p>
      </div>
    </div>
  );
};

export default Hero;