import React from 'react';

interface FunctionFeatureProps {
  title: string;
  description: string;
  imageUrl: string;
  imageAlt: string;
  reverse?: boolean;
}

const FunctionFeature: React.FC<FunctionFeatureProps> = ({ title, description, imageUrl, imageAlt, reverse = false }) => (
  <div className={`lg:grid lg:grid-cols-2 lg:gap-12 lg:items-center ${reverse ? 'lg:grid-flow-col-dense' : ''}`}>
    <div className={`relative ${reverse ? 'lg:col-start-2' : ''}`}>
      <img className="rounded-lg shadow-xl w-full" src={imageUrl} alt={imageAlt} />
    </div>
    <div className={`mt-8 lg:mt-0 ${reverse ? 'lg:col-start-1' : ''}`}>
      <h3 className="text-2xl font-extrabold text-gray-900 tracking-tight sm:text-3xl">{title}</h3>
      <p className="mt-3 text-lg text-gray-500">{description}</p>
    </div>
  </div>
);

const IntuitiveFunctions: React.FC = () => {
  return (
    <div className="py-16 bg-white sm:py-24 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 tracking-tight sm:text-4xl">
            주요 기능: 직관적인 편리함
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            'angle'은 복잡한 전력 없이, 사용자의 편의를 극대화하는 직관적이고 효율적인 기계식·유압식 기능들을 탑재했습니다.
          </p>
        </div>

        <div className="mt-16 space-y-16">
          <FunctionFeature
            title="유압식 각도 조절"
            description="상판에 적용된 유압식 각도 조절 장치 덕분에, 한 손으로 레버를 누르는 것만으로 원하는 각도로 부드럽고 간편하게 조절할 수 있습니다."
            imageUrl="./user_image_11.jpg"
            imageAlt="유압식 각도 조절 장치 메커니즘"
          />
          <FunctionFeature
            title="회동형 낙하 방지 받침대"
            description="상판을 기울였을 때 책이나 전자기기가 미끄러지지 않도록 '회동형 낙하 방지 받침대'를 적용했습니다. 복잡한 장치 없이 효율적인 방식으로 안정성을 보장합니다."
            imageUrl="./user_image_9.jpg"
            imageAlt="회동형 낙하 방지 받침대 작동 모습"
            reverse
          />
           <FunctionFeature
            title="적층 가능 구조 (Nesting)"
            description="여러 제품을 효율적으로 겹쳐 쌓을 수 있는 적층(Nesting) 구조로 설계되어, 보관 및 이동 시 공간 활용성을 극대화합니다."
            imageUrl="./user_image_2.jpg"
            imageAlt="여러 개가 겹쳐 보관된 Angle 데스크"
            reverse
          />
           <FunctionFeature
            title="탈부착 및 접이식 선반"
            description="강연대 및 교탁용 모델은 탈부착 또는 접이식 선반을 갖추고 있습니다. 필요에 따라 추가 작업 공간을 확보하고, 사용하지 않을 때는 접어서 공간을 절약할 수 있습니다."
            imageUrl="./user_image_10.jpg"
            imageAlt="접이식 선반이 펼쳐지고 접히는 과정"
          />
        </div>
      </div>
    </div>
  );
};

export default IntuitiveFunctions;