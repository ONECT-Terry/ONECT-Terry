import React from 'react';

const Philosophy: React.FC = () => {
  return (
    <div className="bg-gray-50 py-16 sm:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:text-center">
          <h2 className="text-base font-semibold text-indigo-600 tracking-wider uppercase">디자인 의도와 컨셉</h2>
          <p className="mt-2 text-3xl font-extrabold text-gray-900 tracking-tight sm:text-4xl">
            사람 중심의 기본에 충실한 디자인
          </p>
          <p className="mt-4 max-w-4xl mx-auto text-xl text-gray-500">
            기존 책상의 직선 외형을 축소하고 사선과 곡선을 확대하여 시각적 편안함을 추구했습니다. 이 과정에서 한글 'ㅅ'과 한자 '사람 인(人)'의 상징적 형상을 발견하여 사람 중심이라는 기획 의도를 디자인에 녹여냈습니다.
          </p>
        </div>
        
        <div className="mt-12 lg:mt-16 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div>
              <h3 className="text-xl font-bold text-gray-900">상징적 형태: 사람 인(人)</h3>
              <p className="mt-2 text-gray-600">
                제품 옆면은 '사람 인(人)'자 형태를 모티브로 하여, 모든 디자인이 사용자를 향하고 있음을 상징적으로 보여줍니다. 이는 안전성과 인체공학적 설계를 최우선으로 고려한 저희의 디자인 철학을 담고 있습니다.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900">상징적 각도: 37°</h3>
              <p className="mt-2 text-gray-600">
                데스크 다리의 37° 각도는 사람의 평균 체온에서 영감을 얻었습니다. 따뜻함과 안정감을 주는 이 각도는 사용자에게 가장 편안한 환경을 제공하려는 저희의 세심한 배려를 나타냅니다.
              </p>
            </div>
             <div>
              <h3 className="text-xl font-bold text-gray-900">제품명: Angle</h3>
              <p className="mt-2 text-gray-600">
                제품명 'Angle'은 핵심 기능인 '상판 각도 조절'을 직관적으로 나타내며, 다각도로 사용자의 편의를 고려했음을 의미합니다.
              </p>
            </div>
          </div>
          <div className="grid grid-cols-1 gap-4">
              <img src="./user_image_7.jpg" alt="angle 데스크 디자인 스케치" className="rounded-lg shadow-xl w-full h-auto object-cover"/>
              <img src="./user_image_8.jpg" alt="angle 데스크 측면 구조도" className="rounded-lg shadow-xl w-full h-auto object-cover"/>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Philosophy;