import React from 'react';

const images = [
  { src: './user_image_4.jpg', alt: '다양한 색상의 angle 데스크' },
  { src: './user_image_5.jpg', alt: '블랙과 오렌지 색상의 angle 데스크' },
  { src: './user_image_6_set_1.jpg', alt: '교실에 배치된 angle 데스크' },
  { src: './user_image_4_set_1.jpg', alt: '교사용 angle 제품' },
  { src: './user_image_13.jpg', alt: '학생용 angle 제품' },
  { src: './user_image_1.jpg', alt: '현대적인 교실의 angle 데스크' },
];

const ProductGallery: React.FC = () => {
  return (
    <div className="bg-gray-50 py-16 sm:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-base font-semibold text-indigo-600 tracking-wider uppercase">제품 갤러리</h2>
          <p className="mt-2 text-3xl font-extrabold text-gray-900 tracking-tight sm:text-4xl">
            어떤 공간에도 어울리는 디자인
          </p>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            'angle' 데스크가 만들어내는 다채롭고 효율적인 공간의 모습을 확인해보세요.
          </p>
        </div>
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {images.map((image, index) => (
            <div key={index} className="overflow-hidden rounded-lg shadow-lg group">
              <img
                src={image.src}
                alt={image.alt}
                className="w-full h-64 object-cover transform group-hover:scale-105 transition-transform duration-300 ease-in-out"
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProductGallery;