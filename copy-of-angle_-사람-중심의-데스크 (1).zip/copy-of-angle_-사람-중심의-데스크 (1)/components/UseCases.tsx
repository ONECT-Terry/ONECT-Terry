import React from 'react';

const UseCaseCard: React.FC<{ title: string, description: string, imageUrl: string }> = ({ title, description, imageUrl }) => (
  <div className="flex flex-col">
    <img src={imageUrl} alt={title} className="w-full h-64 object-cover rounded-lg shadow-lg mb-4"/>
    <h3 className="text-xl font-bold text-gray-900">{title}</h3>
    <p className="mt-2 text-gray-600">{description}</p>
  </div>
);

const UseCases: React.FC = () => {
  return (
    <div className="bg-gray-50 py-16 sm:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-base font-semibold text-indigo-600 tracking-wider uppercase">디자인 활용</h2>
          <p className="mt-2 text-3xl font-extrabold text-gray-900 tracking-tight sm:text-4xl">
            모든 교육 환경을 위한 최적의 솔루션
          </p>
          <p className="mt-4 max-w-3xl mx-auto text-xl text-gray-500">
            상판 각도 조절 기능은 사용자가 올바른 자세를 유지하도록 도와줍니다. 일반 강의실부터 특수 교실까지, 학생과 교사 모두에게 높은 활용성을 제공하여 교육의 질을 높입니다.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          <UseCaseCard
            title="일반 및 자세 교정"
            description="책 거치대처럼 사용하여 허리를 굽히지 않고 바른 자세로 학습에 집중할 수 있습니다. 장시간 사용에도 편안함을 제공합니다."
            imageUrl="./user_image_6.jpg"
          />
          <UseCaseCard
            title="예체능 실기 수업"
            description="미술 시간에는 이젤로, 음악 시간에는 악보 거치대로 변신합니다. 다양한 실기 수업에서 학생들의 창의성을 극대화합니다."
            imageUrl="./user_image_7_set_1.jpg"
          />
          <UseCaseCard
            title="교사 및 강연자"
            description="스탠딩 강연 시 노트북 거치대로 최적이며, 접이식 선반 모델은 추가 공간을 제공하여 교탁으로도 손색이 없습니다."
            imageUrl="./user_image_8_set_1.jpg"
          />
        </div>
      </div>
    </div>
  );
};

export default UseCases;