export interface AccordionItem {
  title: string;
  content: string;
}

// FIX: Add and export the missing ChartData interface.
export interface ChartData {
  name: string;
  value: number;
}
